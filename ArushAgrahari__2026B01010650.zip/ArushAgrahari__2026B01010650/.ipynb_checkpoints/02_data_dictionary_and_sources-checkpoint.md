# Data Sources & Data Dictionary

## 1. Dataset Provenance & Licence
* **Dataset Name:** Telco Customer Churn (`WA_Fn-UseC_-Telco-Customer-Churn.csv`)
* **Origin:** IBM Sample Data Sets (Customer Retention Program)
* **Access URL:** https://www.kaggle.com/datasets/blastchar/telco-customer-churn
* **Licence:** Data files © Original Authors (Public educational/analytical sample dataset)
* **Analytical Grain:** 1 row = 1 unique telecommunications customer (`7,043` rows, `21` raw columns; `26` columns after feature engineering).
* **Temporal Coverage:** Cross-sectional customer snapshot with tenure ranging from `0` to `72` months (no calendar timestamps included).

## 2. Raw Fields Dictionary
| Column Name | Data Type | Description & Values | Cleaning / Validation Notes |
| :--- | :--- | :--- | :--- |
| `customerID` | String | Unique subscriber identifier (Primary Key) | Verified 7,043 unique values; 0 duplicates |
| `gender` | Categorical | Customer gender (`Male`, `Female`) | Validated; 0 missing values |
| `SeniorCitizen` | Integer -> Cat | Whether customer is 65+ (`0` = No, `1` = Yes) | Mapped `0`/`1` to `No`/`Yes` for readability |
| `Partner` | Categorical | Whether customer has a partner (`Yes`, `No`) | Validated; 0 missing values |
| `Dependents` | Categorical | Whether customer has dependents (`Yes`, `No`) | Validated; 0 missing values |
| `tenure` | Integer | Months the customer has stayed (`0` to `72`) | Validated non-negative integers |
| `PhoneService` | Categorical | Home phone service (`Yes`, `No`) | Validated |
| `MultipleLines` | Categorical | Multiple lines (`Yes`, `No`, `No phone service`) | Validated |
| `InternetService` | Categorical | Internet provider (`DSL`, `Fiber optic`, `No`) | Validated |
| `OnlineSecurity` | Categorical | Add-on security (`Yes`, `No`, `No internet service`) | Validated |
| `OnlineBackup` | Categorical | Add-on cloud backup (`Yes`, `No`, `No internet service`) | Validated |
| `DeviceProtection` | Categorical | Device protection plan (`Yes`, `No`, `No internet service`) | Validated |
| `TechSupport` | Categorical | Priority tech support (`Yes`, `No`, `No internet service`) | Validated |
| `StreamingTV` | Categorical | Streaming TV add-on (`Yes`, `No`, `No internet service`) | Validated |
| `StreamingMovies` | Categorical | Streaming movies add-on (`Yes`, `No`, `No internet service`) | Validated |
| `Contract` | Categorical | Contract term (`Month-to-month`, `One year`, `Two year`) | Key segmentation variable |
| `PaperlessBilling` | Categorical | Electronic billing (`Yes`, `No`) | Validated |
| `PaymentMethod` | Categorical | `Electronic check`, `Mailed check`, `Bank transfer (automatic)`, `Credit card (automatic)` | Validated |
| `MonthlyCharges` | Float | Current monthly bill amount ($ USD) | Validated range `$18.25` – `$118.75` |
| `TotalCharges` | String -> Float | Cumulative amount charged ($ USD) | Coerced from string; 11 blank spaces (`tenure == 0`) imputed as `0.0` |
| `Churn` | Categorical | Target flag: left within last month (`Yes`, `No`) | Class balance: `26.54%` Yes (`1,869`), `73.46%` No (`5,174`) |

## 3. Engineered Features (`telco_churn_clean.csv`)
| Column Name | Data Type | Formula / Definition | Purpose |
| :--- | :--- | :--- | :--- |
| `Churn_Flag` | Integer | `1` if `Churn == 'Yes'` else `0` | Enables vectorised mean/rate calculations |
| `Active_Services_Count` | Integer | Count of `'Yes'` across 8 phone/internet add-on columns (`0`–`8`) | Measures service stickiness / bundling depth |
| `Tenure_Band` | Categorical | Binned tenure: `0-6m`, `7-12m`, `13-24m`, `25-48m`, `49-72m` | Enables cohort-style retention heatmaps |
| `Expected_Total` | Float | `tenure * MonthlyCharges` | Baseline cumulative billing estimate |
| `Billing_Delta` | Float | `TotalCharges - Expected_Total` | Captures historical price adjustments or discounts |